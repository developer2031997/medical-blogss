<template>
  <div class="text-center">
    <h1 class="py-4 text-4xl">About Page</h1>
    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      aliquid dolorem veniam eum qui atque voluptate magnam corporis recusandae
      accusamus reprehenderit vero deleniti neque ratione? Repellendus
      perferendis eius quia hic, odit saepe aperiam qui exercitationem
      aspernatur ipsum facili placeat iste possimus facere, quo quidem fugiat
      corrupti magni consectetur! Harum ab mollitia eius, laboriosam saepe
      expedita reprehenderit exercitationem perspiciatis eaque, veniam vero!
      Amet quae quis eum provident eos sit natus non? Cum distinctio veritatis
      tempora illo itaque excepturi delectus est nobis sapiente, ab dolorum ea
      nesciunt accusamus corporis iste impedit culpa consequuntur? Quia
      recusandae nesciunt quibusdam natus, illo laudantium, ad itaque, rem aut
      dolores quasi soluta sequi iste? Labore quaerat, error ad omnis earum
      sunt, quos neque minima hic incidunt voluptate accusamus fugit dolore
      ullam nostrum, ex perferendis facilis accusantium optio expedita! Ratione
      natus deserunt nam libero officia, quo inventore laboriosam perferendis
      itaque consequatur ipsa ab iciatis cum ab consectetur quas eligendi labore
      tempore. Maxime error quidem assumenda consequatur, aut porro alias harum
      sequi? Tempore modi repellat iure, dolorum, sit atque id totam quasi,
      mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat recusandae
      earum veritatis quam atque dolor necessitatibus enim, quia labore veniam
      neque amet vel voluptates molestiae reiciendis vitae deleniti cum natus
      unde culpa soluta aliquid eius, temporibus sit. Earum neque ducimus amet
      nisi accusamus eveniet beatae dicta deserunt modi totam, quos repellat.
      Voluptates, sed!
    </div>

    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      aliquid dolorem veniam eum qui atque voluptate magnam corporis recusandae
      accusamus reprehenderit vero deleniti neque ratione? Repellendus
      perferendis eius quia hic, odit saepe aperiam qui exercitationem
      aspernatur ipsum facili placeat iste possimus facere, quo quidem fugiat
      corrupti magni consectetur! Harum ab mollitia eius, laboriosam saepe
      expedita reprehenderit exercitationem perspiciatis eaque, veniam vero!
      Amet quae quis eum provident eos sit natus non? Cum distinctio veritatis
      tempora illo itaque excepturi delectus est nobis sapiente, ab dolorum ea
      nesciunt accusamus corporis iste impedit culpa consequuntur? Quia
      recusandae nesciunt quibusdam natus, illo laudantium, ad itaque, rem aut
      dolores quasi soluta sequi iste? Labore quaerat, error ad omnis earum
      sunt, quos neque minima hic incidunt voluptate accusamus fugit dolore
      ullam nostrum, ex perferendis facilis accusantium optio expedita! Ratione
      natus deserunt nam libero officia, quo inventore laboriosam perferendis
      itaque consequatur ipsa ab iciatis cum ab consectetur quas eligendi labore
      tempore. Maxime error quidem assumenda consequatur, aut porro alias harum
      sequi? Tempore modi repellat iure, dolorum, sit atque id totam quasi,
      mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat recusandae
      earum veritatis quam atque dolor necessitatibus enim, quia labore veniam
      neque amet vel voluptates molestiae reiciendis vitae deleniti cum natus
      unde culpa soluta aliquid eius, temporibus sit. Earum neque ducimus amet
      nisi accusamus eveniet beatae dicta deserunt modi totam, quos repellat.
      Voluptates, sed!
    </div>

    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      aliquid dolorem veniam eum qui atque voluptate magnam corporis recusandae
      accusamus reprehenderit vero deleniti neque ratione? Repellendus
      perferendis eius quia hic, odit saepe aperiam qui exercitationem
      aspernatur ipsum facili placeat iste possimus facere, quo quidem fugiat
      corrupti magni consectetur! Harum ab mollitia eius, laboriosam saepe
      expedita reprehenderit exercitationem perspiciatis eaque, veniam vero!
      Amet quae quis eum provident eos sit natus non? Cum distinctio veritatis
      tempora illo itaque excepturi delectus est nobis sapiente, ab dolorum ea
      nesciunt accusamus corporis iste impedit culpa consequuntur? Quia
      recusandae nesciunt quibusdam natus, illo laudantium, ad itaque, rem aut
      dolores quasi soluta sequi iste? Labore quaerat, error ad omnis earum
      sunt, quos neque minima hic incidunt voluptate accusamus fugit dolore
      ullam nostrum, ex perferendis facilis accusantium optio expedita! Ratione
      natus deserunt nam libero officia, quo inventore laboriosam perferendis
      itaque consequatur ipsa ab iciatis cum ab consectetur quas eligendi labore
      tempore. Maxime error quidem assumenda consequatur, aut porro alias harum
      sequi? Tempore modi repellat iure, dolorum, sit atque id totam quasi,
      mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat recusandae
      earum veritatis quam atque dolor necessitatibus enim, quia labore veniam
      neque amet vel voluptates molestiae reiciendis vitae deleniti cum natus
      unde culpa soluta aliquid eius, temporibus sit. Earum neque ducimus amet
      nisi accusamus eveniet beatae dicta deserunt modi totam, quos repellat.
      Voluptates, sed!
    </div>
  </div>
</template>

<script setup>
useHead({
  title: "Medical Blog Website",
});
</script>

<style></style>
