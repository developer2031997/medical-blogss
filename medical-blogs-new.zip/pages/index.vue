<template>
  <div class="text-center">
    <h1 class="pt-4 text-4xl">Home Page</h1>
    <br />
    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      doloribus dolore laborum magni numquam? Quae cupiditate dolorem dolore ea
      eos dolorum sit libero, et quasi magnam suscipit dolor minima error fugiat
      doloremque commodi? Adipisci quidem harum quia, minus delectus error atque
      fugiat eaque quis a iste autem eos, ducimus possimus odit quisquam
      consequuntur asperiores, perspiciatis cum ab consectetur quas eligendi
      labore tempore. Maxime error quidem assumenda consequatur, aut porro alias
      harum sequi? Tempore modi repellat iure, dolorum, sit atque id totam
      quasi, mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat
      recusandae earum veritatis quam atque dolor necessitatibus enim, quia
      labore veniam neque amet vel voluptates molestiae reiciendis vitae
      deleniti cum natus unde culpa soluta aliquid eius, temporibus sit. Earum
      neque ducimus amet nisi accusamus eveniet beatae dicta deserunt modi
      totam, quos repellat. Voluptates, sed!
    </div>
    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      doloribus dolore laborum magni numquam? Quae cupiditate dolorem dolore ea
      eos dolorum sit libero, et quasi magnam suscipit dolor minima error fugiat
      doloremque commodi? Adipisci quidem harum quia, minus delectus error atque
      fugiat eaque quis a iste autem eos, ducimus possimus odit quisquam
      consequuntur asperiores, perspiciatis cum ab consectetur quas eligendi
      labore tempore. Maxime error quidem assumenda consequatur, aut porro alias
      harum sequi? Tempore modi repellat iure, dolorum, sit atque id totam
      quasi, mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat
      recusandae earum veritatis quam atque dolor necessitatibus enim, quia
      labore veniam neque amet vel voluptates molestiae reiciendis vitae
      deleniti cum natus unde culpa soluta aliquid eius, temporibus sit. Earum
      neque ducimus amet nisi accusamus eveniet beatae dicta deserunt modi
      totam, quos repellat. Voluptates, sed!
    </div>
    <div class="py-3 mx-5">
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quaerat rem
      reiciendis sunt, debitis autem laudantium ducimus. A eaque, fugit nobis
      doloribus dolore laborum magni numquam? Quae cupiditate dolorem dolore ea
      eos dolorum sit libero, et quasi magnam suscipit dolor minima error fugiat
      doloremque commodi? Adipisci quidem harum quia, minus delectus error atque
      fugiat eaque quis a iste autem eos, ducimus possimus odit quisquam
      consequuntur asperiores, perspiciatis cum ab consectetur quas eligendi
      labore tempore. Maxime error quidem assumenda consequatur, aut porro alias
      harum sequi? Tempore modi repellat iure, dolorum, sit atque id totam
      quasi, mollitia consequatur quisquam nesciunt veritatis dolor? Quaerat
      recusandae earum veritatis quam atque dolor necessitatibus enim, quia
      labore veniam neque amet vel voluptates molestiae reiciendis vitae
      deleniti cum natus unde culpa soluta aliquid eius, temporibus sit. Earum
      neque ducimus amet nisi accusamus eveniet beatae dicta deserunt modi
      totam, quos repellat. Voluptates, sed!
    </div>
  </div>
</template>

<script setup>
useHead({
  title: "Nuxt Content Medical Blog",
});
</script>

<style>
body {
  font-family: "Poppins", sans-serif;
}
</style>
