import{_ as o,o as r,c as s,$ as t}from"./CRt3GJZp.js";const c={};function n(e,l){return r(),s("ol",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
