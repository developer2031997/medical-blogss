import{_ as r,o,c as t,$ as s}from"./CRt3GJZp.js";const c={};function n(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
