import{y as n,B as e}from"./CRt3GJZp.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
