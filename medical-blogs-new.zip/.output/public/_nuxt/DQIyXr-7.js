import{_ as o,o as r,c as s,$ as t}from"./CRt3GJZp.js";const c={};function n(e,a){return r(),s("em",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
