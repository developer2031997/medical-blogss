let configs
export function getMdcConfigs () {
if (!configs) {
  configs = Promise.all([
  ])
}
return configs
}