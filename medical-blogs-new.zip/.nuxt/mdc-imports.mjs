
export const remarkPlugins = {
}

export const rehypePlugins = {
}

export const highlight = {}