declare module '#content/server' {
  const serverQueryContent: typeof import('C:/Users/Admin/Desktop/Akshay/nuxt/medical-blogs/node_modules/@nuxt/content/dist/runtime/legacy/types').serverQueryContent
  const parseContent: typeof import('C:/Users/Admin/Desktop/Akshay/nuxt/medical-blogs/node_modules/@nuxt/content/dist/runtime/server').parseContent
}